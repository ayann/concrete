<?php    
defined('C5_EXECUTE') or die(_("Access Denied."));
$GalleryObj=$controller;
?>

<?php     $this->inc('form_setup_html.php'); ?> 